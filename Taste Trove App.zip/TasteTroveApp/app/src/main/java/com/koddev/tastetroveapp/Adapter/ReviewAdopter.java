package com.koddev.tastetroveapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.koddev.tastetroveapp.Model.Rating;
import com.koddev.tastetroveapp.R;

import java.util.List;

public class ReviewAdopter extends RecyclerView.Adapter<ReviewAdopter.RecyclerHolder> {
    private Context mContext;
    private List<Rating> mUploads;

    public ReviewAdopter(Context mContext, List<Rating> mUploads) {
        this.mContext = mContext;
        this.mUploads = mUploads;
    }

    @Override
    public RecyclerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.review_list, parent, false);
        return new RecyclerHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerHolder holder, int position) {
        Rating uploadCurrent = mUploads.get(position);
        holder.txtmsg.setText(uploadCurrent.getrMsg());
        holder.txtname.setText(uploadCurrent.getuName());
        holder.txtdate.setText(uploadCurrent.getrDate());
        holder.ratingbar3.setRating(Float.valueOf(uploadCurrent.getrStart()));
    }

    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public class RecyclerHolder extends RecyclerView.ViewHolder {
        TextView txtmsg,txtname,txtdate;
        RatingBar ratingbar3;
        public RecyclerHolder(@NonNull View itemView) {
            super(itemView);
            txtmsg = itemView.findViewById(R.id.txtmsg);
            txtname = itemView.findViewById(R.id.txtname);
            txtdate = itemView.findViewById(R.id.txtdate);
            ratingbar3 = itemView.findViewById(R.id.ratingbar3);

        }
    }
}
