package com.koddev.tastetroveapp.Model;

public class Favourite {
    public String fName;
    public String fDes;
    public String fRate;
    public String fPrice;
    public String fImage;
    public String uID;
    public String fID;


    public Favourite() {
    }

    public Favourite(String fName, String fDes, String fRate, String fPrice, String fImage, String uID, String fID) {
        this.fName = fName;
        this.fDes = fDes;
        this.fRate = fRate;
        this.fPrice = fPrice;
        this.fImage = fImage;
        this.uID = uID;
        this.fID = fID;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getfDes() {
        return fDes;
    }

    public void setfDes(String fDes) {
        this.fDes = fDes;
    }

    public String getfRate() {
        return fRate;
    }

    public void setfRate(String fRate) {
        this.fRate = fRate;
    }

    public String getfPrice() {
        return fPrice;
    }

    public void setfPrice(String fPrice) {
        this.fPrice = fPrice;
    }

    public String getfImage() {
        return fImage;
    }

    public void setfImage(String fImage) {
        this.fImage = fImage;
    }

    public String getuID() {
        return uID;
    }

    public void setuID(String uID) {
        this.uID = uID;
    }

    public String getfID() {
        return fID;
    }

    public void setfID(String fID) {
        this.fID = fID;
    }
}
