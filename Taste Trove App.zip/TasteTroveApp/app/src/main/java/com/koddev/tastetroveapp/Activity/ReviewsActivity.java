package com.koddev.tastetroveapp.Activity;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.Adapter.ReviewAdopter;
import com.koddev.tastetroveapp.Model.Rating;
import com.koddev.tastetroveapp.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReviewsActivity extends AppCompatActivity {
    Dialog mDialog;
    DatabaseReference databaseReference3,databaseReference2,mDataBaseReference;
    FirebaseAuth firebaseAuth;
    String uID,uName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviews);
        getSupportActionBar().hide();
        //Dialog Frame call
        mDialog = new Dialog(this);
        mDialog.setContentView(R.layout.feedback_dialogbox);
        mDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        uID = firebaseUser.getUid();
        databaseReference2 = FirebaseDatabase.getInstance().getReference().child("User").child(uID);
        databaseReference2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                uName = dataSnapshot.child("uName").getValue(String.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        showData();
    }

    public void closed(View view) {
        finish();
    }

    public void reviews(View view) {
        mDialog.show();
        RatingBar ratingbar2 = mDialog.findViewById(R.id.ratingbar2);
        TextView txtsubmit = mDialog.findViewById(R.id.txtsubmit);
        EditText edtmsg = mDialog.findViewById(R.id.edtmsg);
        TextView txtcancel = mDialog.findViewById(R.id.txtcancel);
        txtcancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        txtsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edtmsg.getText().toString().isEmpty()){
                    edtmsg.setError("Please enter message");
                }else {
                    if(ratingbar2.getRating() == 0.0){
                        Toast.makeText(ReviewsActivity.this , "Enter rating", Toast.LENGTH_SHORT).show();
                    }else {
                        String date = new SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(new Date());
                        String pID = Constants.pID;
                        databaseReference3 = FirebaseDatabase.getInstance().getReference().child("Rating");
                        String uKey = databaseReference3.push().getKey();
                        Rating rating = new Rating(edtmsg.getText().toString(),String.valueOf(ratingbar2.getRating()),date,uID,uName,pID,uKey);
                        databaseReference3.child(uKey).setValue(rating).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                databaseReference3.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        Toast.makeText(ReviewsActivity.this, "Review submit", Toast.LENGTH_SHORT).show();
                                        mDialog.dismiss();
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                    }
                                });

                            }
                        });
                    }
                }

            }
        });
    }
    ProgressBar progress_circle_product;
    RecyclerView mRecyclerView;
    List<Rating> mUploads;
    ReviewAdopter homeAdopter;
    public void  showData(){
        mRecyclerView = findViewById(R.id.mRecyclerView);
        progress_circle_product = findViewById(R.id.progress_circle_product);
        mUploads = new ArrayList<>();
        homeAdopter = new ReviewAdopter(this, mUploads);
        mRecyclerView.setAdapter(homeAdopter);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this,1));
        mDataBaseReference = FirebaseDatabase.getInstance().getReference().child("Rating");
        mDataBaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUploads.clear();
                for(DataSnapshot postSnapShot : dataSnapshot.getChildren())
                {
                    Rating product = postSnapShot.getValue(Rating.class);
                    if(product.getpID().equals(Constants.pID)) {
                        product.setuKey(postSnapShot.getKey());
                        mUploads.add(product);
                        progress_circle_product.setVisibility(View.GONE);
                    }
                }
                homeAdopter.notifyDataSetChanged();
                progress_circle_product.setVisibility(View.GONE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ReviewsActivity.this, databaseError.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}