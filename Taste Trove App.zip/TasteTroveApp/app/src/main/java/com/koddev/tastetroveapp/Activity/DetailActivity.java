package com.koddev.tastetroveapp.Activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.Adapter.ReviewAdopter;
import com.koddev.tastetroveapp.Model.Rating;
import com.koddev.tastetroveapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class DetailActivity extends AppCompatActivity {
    ImageView imageView2,imageViewFav;
    TextView txtname,txtprice,ratting,txtcagetory,txtdes,txtReviews;
    DatabaseReference databaseReference2,mDataBaseReference;
    LinearLayout ingredient,ingredient1,ingredient2,ingredient3,ingredient4,ingredient5,ingredient6;
    TextView txt1,txt2,txt3,txt4,txt5,txt6,txt7,txt8;
    TextView txt11,txt22,txt33,txt44,txt55,txt66,txt77,txt88;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().hide();
        txtReviews = findViewById(R.id.txtReviews);
        txtReviews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.pID = Constants.pID_Detail;
                startActivity(new Intent(DetailActivity.this, ReviewsActivity.class));
            }
        });
        showData();
        txt1 = findViewById(R.id.txt1);
        txt11 = findViewById(R.id.txt11);
        txt2 = findViewById(R.id.txt2);
        txt22 = findViewById(R.id.txt22);
        txt3 = findViewById(R.id.txt3);
        txt33 = findViewById(R.id.txt33);
        txt4 = findViewById(R.id.txt4);
        txt44 = findViewById(R.id.txt44);
        txt5 = findViewById(R.id.txt5);
        txt55 = findViewById(R.id.txt55);
        txt6 = findViewById(R.id.txt6);
        txt66 = findViewById(R.id.txt66);
        txt7 = findViewById(R.id.txt7);
        txt77 = findViewById(R.id.txt77);
        txt8 = findViewById(R.id.txt8);
        txt88 = findViewById(R.id.txt88);
        ingredient1 = findViewById(R.id.ingredient1);
        ingredient2 = findViewById(R.id.ingredient2);
        ingredient3 = findViewById(R.id.ingredient3);
        ingredient4 = findViewById(R.id.ingredient4);
        ingredient5 = findViewById(R.id.ingredient5);
        ingredient6 = findViewById(R.id.ingredient6);
        ingredient = findViewById(R.id.ingredient);
        imageView2 = findViewById(R.id.imageView2);
        txtdes = findViewById(R.id.txtdes);
        imageViewFav = findViewById(R.id.imageViewFav);
        txtname = findViewById(R.id.txtname);
        txtprice = findViewById(R.id.txtprice);
        ratting = findViewById(R.id.ratting);
        txtcagetory = findViewById(R.id.txtcagetory);
        checkFavoriteStatus(Constants.pID_Detail, imageViewFav);

        databaseReference2 = FirebaseDatabase.getInstance().getReference("Product").child(Constants.pID_Detail);
        databaseReference2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String fName = dataSnapshot.child("fName").getValue(String.class);
                String fImg = dataSnapshot.child("fImg").getValue(String.class);
                String fDes = dataSnapshot.child("fDes").getValue(String.class);
                String fCategory = dataSnapshot.child("fCategory").getValue(String.class);
                String fRating = dataSnapshot.child("fRating").getValue(String.class);
                String fTime = dataSnapshot.child("fTime").getValue(String.class);
                String fVegtype = dataSnapshot.child("fVegtype").getValue(String.class);
                String fIngredients1 = dataSnapshot.child("fIngredients1").getValue(String.class);
                String fIngredients2 = dataSnapshot.child("fIngredients2").getValue(String.class);
                String fIngredients3 = dataSnapshot.child("fIngredients3").getValue(String.class);
                String fIngredients4 = dataSnapshot.child("fIngredients4").getValue(String.class);
                String fIngredients5 = dataSnapshot.child("fIngredients5").getValue(String.class);
                String fIngredients6 = dataSnapshot.child("fIngredients6").getValue(String.class);
                String fStep1 = dataSnapshot.child("fStep1").getValue(String.class);
                if(!fStep1.equals("")){
                    txt1.setText(fStep1);
                    txt1.setVisibility(View.VISIBLE);
                    txt11.setVisibility(View.VISIBLE);
                }else {
                    txt1.setVisibility(View.GONE);
                    txt11.setVisibility(View.GONE);
                }
                String fStep2 = dataSnapshot.child("fStep2").getValue(String.class);
                if(!fStep2.equals("")){
                    txt2.setText(fStep2);
                    txt2.setVisibility(View.VISIBLE);
                    txt22.setVisibility(View.VISIBLE);
                }else {
                    txt2.setVisibility(View.GONE);
                    txt22.setVisibility(View.GONE);
                }
                String fStep3 = dataSnapshot.child("fStep3").getValue(String.class);
                if(!fStep3.equals("")){
                    txt3.setText(fStep3);
                    txt3.setVisibility(View.VISIBLE);
                    txt33.setVisibility(View.VISIBLE);
                }else {
                    txt3.setVisibility(View.GONE);
                    txt33.setVisibility(View.GONE);
                }
                String fStep4 = dataSnapshot.child("fStep4").getValue(String.class);
                if(!fStep4.equals("")){
                    txt4.setText(fStep4);
                    txt4.setVisibility(View.VISIBLE);
                    txt44.setVisibility(View.VISIBLE);
                }else {
                    txt4.setVisibility(View.GONE);
                    txt44.setVisibility(View.GONE);
                }
                String fStep5 = dataSnapshot.child("fStep5").getValue(String.class);
                if(!fStep5.equals("")){
                    txt5.setText(fStep5);
                    txt5.setVisibility(View.VISIBLE);
                    txt55.setVisibility(View.VISIBLE);
                }else {
                    txt5.setVisibility(View.GONE);
                    txt55.setVisibility(View.GONE);
                }
                String fStep6 = dataSnapshot.child("fStep6").getValue(String.class);
                if(!fStep6.equals("")){
                    txt6.setText(fStep6);
                    txt6.setVisibility(View.VISIBLE);
                    txt66.setVisibility(View.VISIBLE);
                }else {
                    txt6.setVisibility(View.GONE);
                    txt66.setVisibility(View.GONE);
                }
                String fStep7 = dataSnapshot.child("fStep7").getValue(String.class);
                if(!fStep7.equals("")){
                    txt7.setText(fStep7);
                    txt7.setVisibility(View.VISIBLE);
                    txt77.setVisibility(View.VISIBLE);
                }else {
                    txt7.setVisibility(View.GONE);
                    txt77.setVisibility(View.GONE);
                }
                String fStep8 = dataSnapshot.child("fStep8").getValue(String.class);
                if(!fStep8.equals("")){
                    txt8.setText(fStep8);
                    txt8.setVisibility(View.VISIBLE);
                    txt88.setVisibility(View.VISIBLE);
                }else {
                    txt8.setVisibility(View.GONE);
                    txt88.setVisibility(View.GONE);
                }
                txtname.setText(fName);
                txtdes.setText(fDes);
                txtprice.setText(fTime);
                txtcagetory.setText(fCategory+" ("+fVegtype+")");
                ratting.setText(fRating);
                Picasso.get().load(fImg).into(imageView2);
                if(fCategory.equals("Traditional")){
                    ingredient.setVisibility(View.VISIBLE);
                }else {
                    ingredient.setVisibility(View.GONE);
                }
                if(fIngredients1.equals("null")){
                    ingredient1.setVisibility(View.GONE);
                }else {
                    ingredient1.setVisibility(View.VISIBLE);
                }
                if(fIngredients2.equals("null")){
                    ingredient2.setVisibility(View.GONE);
                }else {
                    ingredient2.setVisibility(View.VISIBLE);
                }
                if(fIngredients3.equals("null")){
                    ingredient3.setVisibility(View.GONE);
                }else {
                    ingredient3.setVisibility(View.VISIBLE);
                }
                if(fIngredients4.equals("null")){
                    ingredient4.setVisibility(View.GONE);
                }else {
                    ingredient4.setVisibility(View.VISIBLE);
                }
                if(fIngredients5.equals("null")){
                    ingredient5.setVisibility(View.GONE);
                }else {
                    ingredient5.setVisibility(View.VISIBLE);
                }
                if(fIngredients6.equals("null")){
                    ingredient6.setVisibility(View.GONE);
                }else {
                    ingredient6.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    /**
     * Check if the product is already favorited and update the icon color accordingly.
     */
    private void checkFavoriteStatus(String productId, ImageView imageView) {
        DatabaseReference favoritesRef;
        FirebaseAuth auth;
        auth = FirebaseAuth.getInstance();
        if(auth.getCurrentUser()!=null){
            favoritesRef = FirebaseDatabase.getInstance().getReference("isFavorites").child(auth.getCurrentUser().getUid());
            favoritesRef.child(productId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists() && snapshot.getValue(Boolean.class)) {
                        // Product is a favorite, show red heart
                        imageView.setImageResource(R.drawable.baseline_favorite_24_red);
                    } else {
                        // Product is not a favorite, show gray heart
                        imageView.setImageResource(R.drawable.baseline_favorite_border_24);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Handle error
                }
            });
        }

    }
    RecyclerView mRecyclerView;
    List<Rating> mUploads2;
    ReviewAdopter homeAdopter;
    public void  showData(){
        mRecyclerView = findViewById(R.id.mRecyclerView);
        mUploads2 = new ArrayList<>();
        homeAdopter = new ReviewAdopter(this, mUploads2);
        mRecyclerView.setAdapter(homeAdopter);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this,1));
        mDataBaseReference = FirebaseDatabase.getInstance().getReference().child("Rating");
        mDataBaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUploads2.clear();
                for(DataSnapshot postSnapShot : dataSnapshot.getChildren())
                {
                    Rating product = postSnapShot.getValue(Rating.class);
                    if(product.getpID().equals(Constants.pID_Detail)) {
                        product.setuKey(postSnapShot.getKey());
                        mUploads2.add(product);
                    }
                }
                homeAdopter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(DetailActivity.this, databaseError.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void closed(View view) {
        finish();
    }

    public void watch(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(Constants.videoURL));
        startActivity(intent);
    }
}