package com.koddev.tastetroveapp.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.Adapter.TrendingAdapter;
import com.koddev.tastetroveapp.Model.Food;
import com.koddev.tastetroveapp.R;

import java.util.ArrayList;
import java.util.List;

public class SeeAllActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_all);
        getSupportActionBar().hide();
        product();
    }



    List<Food> mUploads2;
    RecyclerView rcProduct;
    ProgressBar progress_circle_product;
    TrendingAdapter categoryAdapter;
    DatabaseReference mDataBaseReference2;
    public void  product(){
        rcProduct = findViewById(R.id.rcProduct);
        progress_circle_product = findViewById(R.id.progress_circle_product);
        mUploads2 = new ArrayList<>();
        categoryAdapter = new TrendingAdapter(this, mUploads2);
        rcProduct.setAdapter(categoryAdapter);
        rcProduct.setLayoutManager(new GridLayoutManager(this,2));
        mDataBaseReference2 = FirebaseDatabase.getInstance().getReference("Product");
        mDataBaseReference2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // dataSnapshot is the "issue" node with all children with id 0
                    for (DataSnapshot user : dataSnapshot.getChildren()) {
                        // do something with the individual "issues"
                        Food product = user.getValue(Food.class);
                        mUploads2.add(product);
                        progress_circle_product.setVisibility(View.GONE);
                    }
                    categoryAdapter.notifyDataSetChanged();
                    progress_circle_product.setVisibility(View.GONE);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void closed(View view) {
        finish();
    }
}