package com.koddev.tastetroveapp.Activity;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.koddev.tastetroveapp.Activity.Fragment.FavFragment;
import com.koddev.tastetroveapp.Activity.Fragment.HomeFragment;
import com.koddev.tastetroveapp.Activity.Fragment.LoginFragment;
import com.koddev.tastetroveapp.R;

public class UserHomeActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);
        getSupportActionBar().hide();
        bottomNavigationView = findViewById(R.id.nav_view);
        loadFragment(new HomeFragment());
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            Fragment fragment = null;
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId() == R.id.navigation_home){
                    fragment = new HomeFragment();
                }else if(item.getItemId() == R.id.navigation_categories){
                    fragment = new FavFragment();
                }else if(item.getItemId() == R.id.navigation_account){
                    fragment = new LoginFragment();
                }
                return loadFragment(fragment);
            }
        });

    }
    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}