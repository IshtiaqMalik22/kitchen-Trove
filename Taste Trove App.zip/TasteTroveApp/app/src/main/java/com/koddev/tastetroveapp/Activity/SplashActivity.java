package com.koddev.tastetroveapp.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.Activity.Admin.AdminActivity;
import com.koddev.tastetroveapp.MainActivity;
import com.koddev.tastetroveapp.R;

public class SplashActivity extends AppCompatActivity {
    private  static  int SPLASH_SCREEN =2500;
    FirebaseAuth firebaseAuthe;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        getSupportActionBar().hide();
        firebaseAuthe= FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = firebaseAuthe.getCurrentUser();
        if(firebaseUser!= null)
        {
            String uID = firebaseUser.getUid();
            databaseReference = FirebaseDatabase.getInstance().getReference().child("User").child(uID);
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    String uType = dataSnapshot.child("uType").getValue(String.class);
                    if(uType.equals("User"))
                    {
                        startActivity(new Intent(SplashActivity.this, UserHomeActivity.class));
                        Toast.makeText(SplashActivity.this, "User Login", Toast.LENGTH_SHORT).show();
                        finish();
                    }else if(uType.equals("Admin"))
                    {
                        startActivity(new Intent(SplashActivity.this, AdminActivity.class));
                        Toast.makeText(SplashActivity.this, "Admin Login", Toast.LENGTH_SHORT).show();
                        finish();
                    }else{
                        startActivity(new Intent(SplashActivity.this, IntroActivity.class));
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }else {
            new Handler().postDelayed(new Runnable()
            {
                @Override
                public void run() {
                    Intent intent = new Intent(SplashActivity.this, IntroActivity.class);
                    startActivity(intent);
                    finish();
                }
            },SPLASH_SCREEN);

        }
//        new Handler().postDelayed(new Runnable()
//        {
//            @Override
//            public void run() {
//                Intent intent = new Intent(SplashActivity.this, UserHomeActivity.class);
//                startActivity(intent);
//                finish();
//            }
//        },SPLASH_SCREEN);

    }
}