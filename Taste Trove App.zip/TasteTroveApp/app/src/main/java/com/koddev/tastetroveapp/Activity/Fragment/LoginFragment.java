package com.koddev.tastetroveapp.Activity.Fragment;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.Activity.Admin.AdminActivity;
import com.koddev.tastetroveapp.Activity.ChangePasswordActivity;
import com.koddev.tastetroveapp.Activity.RegisterActivity;
import com.koddev.tastetroveapp.Activity.UserHomeActivity;
import com.koddev.tastetroveapp.Model.User;
import com.koddev.tastetroveapp.R;


public class LoginFragment extends Fragment {

    EditText edtemail,edtpassword,edtlevel;
    TextView txtpassword,txtlevel,txtforget;
    FirebaseAuth firebaseAuthe;
    ProgressDialog logProgressDialog;
    DatabaseReference mDatabaseRef;
    View root;
    LinearLayout login;
    TextView register;
    TextView txtlogin;
    CheckBox checkbox;
    DatabaseReference databaseReference2;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_login, container, false);
        checkbox = root.findViewById(R.id.checkbox);
        edtemail = root.findViewById(R.id.edtemail);
        edtlevel = root.findViewById(R.id.edtlevel);
        login = root.findViewById(R.id.login);
        txtlevel = root.findViewById(R.id.txtlevel);
        txtpassword = root.findViewById(R.id.txtpassword);
        txtforget = root.findViewById(R.id.txtforget);
        txtforget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), ChangePasswordActivity.class));
            }
        });
        txtlogin = root.findViewById(R.id.txtlogin);
        register = root.findViewById(R.id.register);
        edtpassword = root.findViewById(R.id.edtpassword);
        logProgressDialog =new ProgressDialog(getContext());
        firebaseAuthe= FirebaseAuth.getInstance();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference();
        FirebaseUser firebaseUser = firebaseAuthe.getCurrentUser();
        if(firebaseUser!= null){
            txtlogin.setText("Log out");
            txtpassword.setVisibility(View.GONE);
            txtlevel.setVisibility(View.VISIBLE);
            edtemail.setEnabled(false);
            edtlevel.setEnabled(false);
            edtpassword.setVisibility(View.GONE);
            databaseReference2 = FirebaseDatabase.getInstance().getReference().child("User").child(firebaseUser.getUid());
            databaseReference2.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    String uEmail = dataSnapshot.child("uEmail").getValue(String.class);
                    String uLevel = dataSnapshot.child("uLevel").getValue(String.class);
                    String uContactNo = dataSnapshot.child("uContactNo").getValue(String.class);
                    edtemail.setText(uEmail);
                    edtlevel.setText(uLevel);


                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }else {
            txtlogin.setText("Log In");
            txtpassword.setVisibility(View.VISIBLE);
            txtlevel.setVisibility(View.GONE);
            edtlevel.setVisibility(View.GONE);
            edtemail.setEnabled(true);
            edtpassword.setVisibility(View.VISIBLE);
        }

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuthe = FirebaseAuth.getInstance();
                FirebaseUser firebaseUser = firebaseAuthe.getCurrentUser();
                if(firebaseUser!= null){
                    txtlogin.setText("Log out");
                    AlertDialog.Builder builder1 = new AlertDialog.Builder(getContext());
                    builder1.setMessage("Are you want to logout this app?");
                    builder1.setCancelable(true);

                    builder1.setPositiveButton(
                            "Yes",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                    firebaseAuthe.signOut();
                                    getActivity().finish();
                                    startActivity(new Intent(getContext(), UserHomeActivity.class));
                                }
                            });

                    builder1.setNegativeButton(
                            "No",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alert11 = builder1.create();
                    alert11.show();
                }else {
                    txtlogin.setText("Log In");
                    if(edtemail.getText().toString().isEmpty()){
                        edtemail.setError("Please enter email");
                        Toast.makeText(getContext(), "Please enter email", Toast.LENGTH_SHORT).show();
                    }else {
                        if(edtpassword.getText().toString().isEmpty()){
                            edtpassword.setError("Please enter password");
                            Toast.makeText(getContext(), "Please enter password", Toast.LENGTH_SHORT).show();
                        }else {
                            String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                            if(!edtemail.getText().toString().matches(emailPattern))
                            {
                                Toast.makeText(getContext(), "Please enter valid email", Toast.LENGTH_SHORT).show();
                            }else {
                                if(edtpassword.getText().toString().length() >= 6){
                                    userLogin();
                                }else {
                                    Toast.makeText(getContext(), "Password length greater then 5", Toast.LENGTH_SHORT).show();
                                }
                            }

                        }
                    }

                }







            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), RegisterActivity.class));
            }
        });
        checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Show the password
                edtpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            } else {
                // Hide the password
                edtpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        });

        return root;
    }
    public void userLogin(){
        logProgressDialog.setMessage("Please wait....");
        logProgressDialog.setCanceledOnTouchOutside(false);
        logProgressDialog.show();
        Query query = mDatabaseRef.child("User").orderByChild("uEmail").equalTo(edtemail.getText().toString().trim());
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // dataSnapshot is the "issue" node with all children with id 0
                    for (DataSnapshot user : dataSnapshot.getChildren()) {
                        // do something with the individual "issues"
                        User usersBean = user.getValue(User.class);
                        if (usersBean.getuType().equals("User")) {
                            firebaseAuthe.signInWithEmailAndPassword(edtemail.getText().toString(), edtpassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {

                                        Toast.makeText(getContext(), "User Login", Toast.LENGTH_SHORT).show();
                                        logProgressDialog.dismiss();
                                        startActivity(new Intent(getContext(), UserHomeActivity.class));
                                        getActivity().finishAffinity();

                                    }else{
                                        Toast.makeText(getContext(), "Wong Password", Toast.LENGTH_SHORT).show();
                                        logProgressDialog.dismiss();
                                    }
                                }
                            });
                        }else if (usersBean.getuType().equals("Admin")) {
                            firebaseAuthe.signInWithEmailAndPassword(edtemail.getText().toString(), edtpassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {

                                        Toast.makeText(getContext(), "Admin Login", Toast.LENGTH_SHORT).show();
                                        logProgressDialog.dismiss();
                                        startActivity(new Intent(getContext(), AdminActivity.class));
                                        getActivity().finishAffinity();

                                    }else{
                                        Toast.makeText(getContext(), "Wong Password", Toast.LENGTH_SHORT).show();
                                        logProgressDialog.dismiss();
                                    }
                                }
                            });
                        }else {
                            Toast.makeText(getContext(), "Not exits", Toast.LENGTH_LONG).show();
                            logProgressDialog.dismiss();
                        }

                    }
                } else {
                    Toast.makeText(getContext(), "Not exits", Toast.LENGTH_LONG).show();
                    logProgressDialog.dismiss();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                logProgressDialog.dismiss();
            }
        });
    }

}