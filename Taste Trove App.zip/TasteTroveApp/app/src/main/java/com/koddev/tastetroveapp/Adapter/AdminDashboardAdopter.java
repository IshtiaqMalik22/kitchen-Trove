package com.koddev.tastetroveapp.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.koddev.tastetroveapp.Activity.Admin.EditPlaceActivity;
import com.koddev.tastetroveapp.Model.Food;
import com.koddev.tastetroveapp.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class AdminDashboardAdopter extends RecyclerView.Adapter<AdminDashboardAdopter.RecyclerHolder> {
    private Context mContext;
    private List<Food> mUploads;
    DatabaseReference databaseReference;
    public static String pKey = "";

    public AdminDashboardAdopter(Context mContext, List<Food> mUploads) {
        this.mContext = mContext;
        this.mUploads = mUploads;
    }

    @Override
    public RecyclerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.admin_home_list, parent, false);
        return new RecyclerHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerHolder holder, int position) {
        Food uploadCurrent = mUploads.get(position);
        holder.txtname.setText(uploadCurrent.getfName());
        holder.txtaddress.setText("Category: "+uploadCurrent.getfCategory());
        holder.txtphone.setText("Type: "+uploadCurrent.getfVegtype());
        holder.txttemp.setText("Time: "+uploadCurrent.getfTime());
        holder.txtdes.setText(uploadCurrent.getfDes());
        Picasso.get().load(uploadCurrent.getfImg()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return mUploads.size();
    }



    public class RecyclerHolder extends RecyclerView.ViewHolder {
        TextView txtname,txtaddress,txtphone,txttemp,txtdes;
        ImageView imageView;
        Button btnd,btnupdate;
        public RecyclerHolder(@NonNull View itemView) {
            super(itemView);
            txtname = itemView.findViewById(R.id.txtname);
            txtphone = itemView.findViewById(R.id.txtphone);
            txttemp = itemView.findViewById(R.id.txttemp);
            txtdes = itemView.findViewById(R.id.txtdes);
            txtaddress = itemView.findViewById(R.id.txtaddress);
            imageView = itemView.findViewById(R.id.imageView);
            btnupdate = itemView.findViewById(R.id.btnupdate);
            btnd = itemView.findViewById(R.id.btnd);
            databaseReference = FirebaseDatabase.getInstance().getReference("Product");
            btnd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder1 = new AlertDialog.Builder(mContext);
                    builder1.setMessage("Are you shure to remove this item ?");
                    builder1.setCancelable(true);
                    builder1.setPositiveButton(
                            "Yes",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    int position = getAdapterPosition();
                                    Food uploadCurrent = mUploads.get(position);
                                    databaseReference.child(uploadCurrent.getfID()).removeValue();
                                    Toast.makeText(mContext, "Removed", Toast.LENGTH_SHORT).show();
                                    dialog.cancel();
                                }
                            });
                    builder1.setNegativeButton(
                            "No",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog alert11 = builder1.create();
                    alert11.show();

                }
            });
            btnupdate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    Food uploadCurrent = mUploads.get(position);
                    pKey = uploadCurrent.getfID();
                    mContext.startActivity(new Intent(mContext, EditPlaceActivity.class));
                }
            });


        }
    }
}
