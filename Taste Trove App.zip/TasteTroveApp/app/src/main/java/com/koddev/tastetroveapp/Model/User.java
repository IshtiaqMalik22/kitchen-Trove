package com.koddev.tastetroveapp.Model;


public class User {
    public String uName;
    public String uEmail;
    public String uLevel;
    public String uContactNumber;
    public String uPassword;
    public String uID;
    public String uImage;
    public String uType;


    public User(String uName, String uEmail, String uLevel, String uContactNumber, String uPassword, String uID, String uImage, String uType) {
        this.uName = uName;
        this.uEmail = uEmail;
        this.uLevel = uLevel;
        this.uContactNumber = uContactNumber;
        this.uPassword = uPassword;
        this.uID = uID;
        this.uImage = uImage;
        this.uType = uType;
    }

    public User() {
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getuEmail() {
        return uEmail;
    }

    public void setuEmail(String uEmail) {
        this.uEmail = uEmail;
    }

    public String getuLevel() {
        return uLevel;
    }

    public void setuLevel(String uLevel) {
        this.uLevel = uLevel;
    }

    public String getuContactNumber() {
        return uContactNumber;
    }

    public void setuContactNumber(String uContactNumber) {
        this.uContactNumber = uContactNumber;
    }

    public String getuPassword() {
        return uPassword;
    }

    public void setuPassword(String uPassword) {
        this.uPassword = uPassword;
    }

    public String getuID() {
        return uID;
    }

    public void setuID(String uID) {
        this.uID = uID;
    }

    public String getuImage() {
        return uImage;
    }

    public void setuImage(String uImage) {
        this.uImage = uImage;
    }

    public String getuType() {
        return uType;
    }

    public void setuType(String uType) {
        this.uType = uType;
    }




}
