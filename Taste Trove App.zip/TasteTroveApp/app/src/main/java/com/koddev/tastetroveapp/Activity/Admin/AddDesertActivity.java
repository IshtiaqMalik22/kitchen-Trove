package com.koddev.tastetroveapp.Activity.Admin;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.koddev.tastetroveapp.Model.Food;
import com.koddev.tastetroveapp.R;
import com.squareup.picasso.Picasso;

public class AddDesertActivity extends AppCompatActivity {
    EditText edtTime,edtName,edtDes,edtStep1,edtStep2,edtStep3,edtStep4,edtStep5,edtStep6,edtStep7,edtStep8,edtVideoUrl;
    Spinner spinnerCagegory;
    private RatingBar ratingBar;
    String ratingStar = "";
    ImageView imageView;
    ProgressDialog progressDialog;
    DatabaseReference mDatabaseRef;
    Uri mImageUri;
    StorageTask mUploadTask;
    StorageReference mStorageRef;
    private static final int PICK_IMAGE_REQUEST = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_desert);
        // Initialize checkboxes
        spinnerCagegory = findViewById(R.id.spinnerCagegory);
        edtVideoUrl = findViewById(R.id.edtVideoUrl);
        ratingBar = findViewById(R.id.ratingBar);
        imageView = findViewById(R.id.imageView);
        edtStep1 = findViewById(R.id.edtStep1);
        edtStep2 = findViewById(R.id.edtStep2);
        edtStep3 = findViewById(R.id.edtStep3);
        edtStep4 = findViewById(R.id.edtStep4);
        edtStep5 = findViewById(R.id.edtStep5);
        edtStep6 = findViewById(R.id.edtStep6);
        edtStep7 = findViewById(R.id.edtStep7);
        edtStep8 = findViewById(R.id.edtStep8);
        edtTime = findViewById(R.id.edtTime);
        edtName = findViewById(R.id.edtName);
        progressDialog = new ProgressDialog(this);
        edtDes = findViewById(R.id.edtDes);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFileChooser();
            }
        });
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (fromUser) {
                    ratingStar = String.valueOf(rating);
                }
            }
        });

    }
    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            mImageUri = data.getData();
            Picasso.get().load(mImageUri).into(imageView);
        }

    }
    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    public void add(View view) {
        // Retrieve the text from the EditTexts
        String time = edtTime.getText().toString().trim();
        String name = edtName.getText().toString().trim();
        String description = edtDes.getText().toString().trim();
        String videoURL = edtVideoUrl.getText().toString().trim();

        // Validate the EditText fields
        if (name.isEmpty()) {
            edtName.setError("Name is required");
            edtName.requestFocus();
            return;
        }



        if (time.isEmpty()) {
            edtTime.setError("Time is required");
            edtTime.requestFocus();
            return;
        }

        if (description.isEmpty()) {
            edtDes.setError("Description is required");
            edtDes.requestFocus();
            return;
        }

        if (videoURL.isEmpty()) {
            edtDes.setError("Video URL is required");
            edtDes.requestFocus();
            return;
        }

        mStorageRef = FirebaseStorage.getInstance().getReference("Product_Images");
        mDatabaseRef = FirebaseDatabase.getInstance().getReference();
        uploadProduct();
    }
    public void uploadProduct(){
        if(mImageUri!= null)
        {
            progressDialog.setMessage("Please wait ...");
            progressDialog.show();
            final StorageReference storageReference = mStorageRef.child(System.currentTimeMillis()+"."+getFileExtension(mImageUri));
            mUploadTask = storageReference.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            String pID = mDatabaseRef.push().getKey();
                            Food product = new Food(
                                    uri.toString(),
                                    edtName.getText().toString(),
                                    edtDes.getText().toString(),
                                    edtTime.getText().toString(),
                                    ratingStar,
                                    "null",
                                    "null",
                                    "null",
                                    "null",
                                    "null",
                                    "null",
                                    edtStep1.getText().toString(),
                                    edtStep2.getText().toString(),
                                    edtStep3.getText().toString(),
                                    edtStep4.getText().toString(),
                                    edtStep5.getText().toString(),
                                    edtStep6.getText().toString(),
                                    edtStep7.getText().toString(),
                                    edtStep8.getText().toString(),
                                    "Desert",
                                    spinnerCagegory.getSelectedItem().toString(),
                                    "null",
                                    pID,
                                    edtVideoUrl.getText().toString()

                            );
                            Toast.makeText(AddDesertActivity.this, "Uploaded Successfully", Toast.LENGTH_SHORT).show();
                            mDatabaseRef.child("Product").child(pID).setValue(product);
                            progressDialog.dismiss();
                            finish();

                        }
                    });
                }
            });
        }else {
            Toast.makeText(this, "Choose Image", Toast.LENGTH_SHORT).show();
        }
    }
}