package com.koddev.tastetroveapp.Activity;

public class Constants {
    public static String type = "";
    public static String pID_Detail = "";
    public static String pID = "";
    public static String videoURL = "";
}
