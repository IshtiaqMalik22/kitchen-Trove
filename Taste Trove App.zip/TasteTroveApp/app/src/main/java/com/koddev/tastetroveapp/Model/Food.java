package com.koddev.tastetroveapp.Model;

public class Food {
    public String fImg;
    public String fName;
    public String fDes;
    public String fTime;
    public String fRating;
    public String fIngredients1;
    public String fIngredients2;
    public String fIngredients3;
    public String fIngredients4;
    public String fIngredients5;
    public String fIngredients6;
    public String fStep1;
    public String fStep2;
    public String fStep3;
    public String fStep4;
    public String fStep5;
    public String fStep6;
    public String fStep7;
    public String fStep8;
    public String fCategory;
    public String fVegtype;
    public String fFoodType;
    public String fID;
    public String fURL;

    public Food(String fImg, String fName, String fDes, String fTime, String fRating, String fIngredients1, String fIngredients2, String fIngredients3, String fIngredients4, String fIngredients5, String fIngredients6, String fStep1, String fStep2, String fStep3, String fStep4, String fStep5, String fStep6, String fStep7, String fStep8, String fCategory, String fVegtype, String fFoodType, String fID, String fURL) {
        this.fImg = fImg;
        this.fName = fName;
        this.fDes = fDes;
        this.fTime = fTime;
        this.fRating = fRating;
        this.fIngredients1 = fIngredients1;
        this.fIngredients2 = fIngredients2;
        this.fIngredients3 = fIngredients3;
        this.fIngredients4 = fIngredients4;
        this.fIngredients5 = fIngredients5;
        this.fIngredients6 = fIngredients6;
        this.fStep1 = fStep1;
        this.fStep2 = fStep2;
        this.fStep3 = fStep3;
        this.fStep4 = fStep4;
        this.fStep5 = fStep5;
        this.fStep6 = fStep6;
        this.fStep7 = fStep7;
        this.fStep8 = fStep8;
        this.fCategory = fCategory;
        this.fVegtype = fVegtype;
        this.fFoodType = fFoodType;
        this.fID = fID;
        this.fURL = fURL;
    }

    public Food() {
    }

    public String getfImg() {
        return fImg;
    }

    public void setfImg(String fImg) {
        this.fImg = fImg;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getfDes() {
        return fDes;
    }

    public void setfDes(String fDes) {
        this.fDes = fDes;
    }

    public String getfTime() {
        return fTime;
    }

    public void setfTime(String fTime) {
        this.fTime = fTime;
    }

    public String getfRating() {
        return fRating;
    }

    public void setfRating(String fRating) {
        this.fRating = fRating;
    }

    public String getfIngredients1() {
        return fIngredients1;
    }

    public void setfIngredients1(String fIngredients1) {
        this.fIngredients1 = fIngredients1;
    }

    public String getfIngredients2() {
        return fIngredients2;
    }

    public void setfIngredients2(String fIngredients2) {
        this.fIngredients2 = fIngredients2;
    }

    public String getfIngredients3() {
        return fIngredients3;
    }

    public void setfIngredients3(String fIngredients3) {
        this.fIngredients3 = fIngredients3;
    }

    public String getfIngredients4() {
        return fIngredients4;
    }

    public void setfIngredients4(String fIngredients4) {
        this.fIngredients4 = fIngredients4;
    }

    public String getfIngredients5() {
        return fIngredients5;
    }

    public void setfIngredients5(String fIngredients5) {
        this.fIngredients5 = fIngredients5;
    }

    public String getfIngredients6() {
        return fIngredients6;
    }

    public void setfIngredients6(String fIngredients6) {
        this.fIngredients6 = fIngredients6;
    }

    public String getfStep1() {
        return fStep1;
    }

    public void setfStep1(String fStep1) {
        this.fStep1 = fStep1;
    }

    public String getfStep2() {
        return fStep2;
    }

    public void setfStep2(String fStep2) {
        this.fStep2 = fStep2;
    }

    public String getfStep3() {
        return fStep3;
    }

    public void setfStep3(String fStep3) {
        this.fStep3 = fStep3;
    }

    public String getfStep4() {
        return fStep4;
    }

    public void setfStep4(String fStep4) {
        this.fStep4 = fStep4;
    }

    public String getfStep5() {
        return fStep5;
    }

    public void setfStep5(String fStep5) {
        this.fStep5 = fStep5;
    }

    public String getfStep6() {
        return fStep6;
    }

    public void setfStep6(String fStep6) {
        this.fStep6 = fStep6;
    }

    public String getfStep7() {
        return fStep7;
    }

    public void setfStep7(String fStep7) {
        this.fStep7 = fStep7;
    }

    public String getfStep8() {
        return fStep8;
    }

    public void setfStep8(String fStep8) {
        this.fStep8 = fStep8;
    }

    public String getfCategory() {
        return fCategory;
    }

    public void setfCategory(String fCategory) {
        this.fCategory = fCategory;
    }

    public String getfVegtype() {
        return fVegtype;
    }

    public void setfVegtype(String fVegtype) {
        this.fVegtype = fVegtype;
    }

    public String getfFoodType() {
        return fFoodType;
    }

    public void setfFoodType(String fFoodType) {
        this.fFoodType = fFoodType;
    }

    public String getfID() {
        return fID;
    }

    public void setfID(String fID) {
        this.fID = fID;
    }

    public String getfURL() {
        return fURL;
    }

    public void setfURL(String fURL) {
        this.fURL = fURL;
    }
}
