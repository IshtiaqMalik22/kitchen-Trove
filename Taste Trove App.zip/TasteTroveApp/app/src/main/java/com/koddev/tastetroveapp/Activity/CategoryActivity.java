package com.koddev.tastetroveapp.Activity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.Adapter.TrendingAdapter;
import com.koddev.tastetroveapp.Model.Food;
import com.koddev.tastetroveapp.R;

import java.util.ArrayList;
import java.util.List;

public class CategoryActivity extends AppCompatActivity {
    TextView txtname;
    private ChipGroup chipGroup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        getSupportActionBar().hide();
        txtname = findViewById(R.id.txtname);
        txtname.setText(Constants.type);
        chipGroup = findViewById(R.id.chipGroup);
        // Sample data
        List<String> chipOptions = new ArrayList<>();
        if(Constants.type.equals("All")) {
            chipOptions.add("All");

        }else if(Constants.type.equals("Desert")){
            chipOptions.add("Non Baking");
            chipOptions.add("Baking");
        }else if(Constants.type.equals("Drink")){
            chipOptions.add("Summer Drink");
            chipOptions.add("Winter Drink");

        }else if(Constants.type.equals("Traditional")){
            chipOptions.add("Non Vegetarian");
            chipOptions.add("Vegetarian");
        }
        for (int i = 0; i < chipOptions.size(); i++) {
            Chip chip = new Chip(this);
            chip.setText(chipOptions.get(i));
            chip.setCheckable(true);
            chip.setCheckedIconEnabled(false);
            chip.setChipBackgroundColorResource(R.color.white);  // Default background color
            chip.setTextColor(Color.parseColor("#000000"));      // Orange text color

            chipGroup.addView(chip);

            // Make the first chip checked by default
            if (i == 0) {
                chip.setChecked(true);
                chip.setChipBackgroundColorResource(R.color.purple_200);  // Set the first chip background to orange
                chip.setTextColor(Color.WHITE);
                if(chip.getText().toString().equals("All")){
                    product();
                }else {
                    product(chip.getText().toString());
                }// White text for the first selected chip

            }

            // Set a listener for chip selection to update background color
            chip.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    // Update the selected chip's background to orange
                    chip.setChipBackgroundColorResource(R.color.purple_500);
                    chip.setTextColor(Color.WHITE);  // Set text color to white when selected

                    // Show data for the selected chip
                    if(chip.getText().toString().equals("All")){
                        product();
                    }else {
                        product(chip.getText().toString());
                    }

                    // Loop through all chips to set unselected chips back to white
                    for (int j = 0; j < chipGroup.getChildCount(); j++) {
                        Chip otherChip = (Chip) chipGroup.getChildAt(j);
                        if (!otherChip.equals(chip)) {
                            otherChip.setChipBackgroundColorResource(R.color.white); // Set background to white
                            otherChip.setTextColor(Color.parseColor("#000000"));
                            // Set text color to orange
                        }
                    }
                }
            });

        }
    }

    List<Food> mUploads2;
    RecyclerView rcProduct;
    ProgressBar progress_circle_product;
    TrendingAdapter categoryAdapter;
    DatabaseReference mDataBaseReference2;
    public void  product(String type) {
        rcProduct = findViewById(R.id.rcProduct);
        progress_circle_product = findViewById(R.id.progress_circle_product);
        mUploads2 = new ArrayList<>();
        categoryAdapter = new TrendingAdapter(this, mUploads2);
        rcProduct.setAdapter(categoryAdapter);
        rcProduct.setLayoutManager(new GridLayoutManager(this, 2));
        mDataBaseReference2 = FirebaseDatabase.getInstance().getReference("Product");
        mDataBaseReference2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // dataSnapshot is the "issue" node with all children with id 0
                    for (DataSnapshot user : dataSnapshot.getChildren()) {
                        // do something with the individual "issues"
                        Food product = user.getValue(Food.class);
                        if(product.getfCategory().equals(Constants.type)) {
                            if(product.getfVegtype().equals(type)) {
                                mUploads2.add(product);
                                progress_circle_product.setVisibility(View.GONE);
                            }
                        }
                    }
                    categoryAdapter.notifyDataSetChanged();
                    progress_circle_product.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
    public void  product() {
        rcProduct = findViewById(R.id.rcProduct);
        progress_circle_product = findViewById(R.id.progress_circle_product);
        mUploads2 = new ArrayList<>();
        categoryAdapter = new TrendingAdapter(this, mUploads2);
        rcProduct.setAdapter(categoryAdapter);
        rcProduct.setLayoutManager(new GridLayoutManager(this, 2));
        mDataBaseReference2 = FirebaseDatabase.getInstance().getReference("Product");
        mDataBaseReference2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // dataSnapshot is the "issue" node with all children with id 0
                    for (DataSnapshot user : dataSnapshot.getChildren()) {
                        // do something with the individual "issues"
                        Food product = user.getValue(Food.class);
                        mUploads2.add(product);
                        progress_circle_product.setVisibility(View.GONE);
                    }
                    categoryAdapter.notifyDataSetChanged();
                    progress_circle_product.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
    public void closed(View view) {
        finish();
    }
}