package com.koddev.tastetroveapp.Activity.Admin;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.koddev.tastetroveapp.Adapter.AdminDashboardAdopter;
import com.koddev.tastetroveapp.R;
import com.squareup.picasso.Picasso;

public class EditPlaceActivity extends AppCompatActivity {
    EditText edtplacename,edtphoneno,edtdescription;
    ImageView imageView2;
    private static final int PICK_IMAGE_REQUEST = 1;
    Uri mImageUri;
    // Database
    StorageReference mStorageRef;
    ProgressDialog progressDialog;
    DatabaseReference mDatabaseRef,databaseReference;
    StorageTask mUploadTask;
    String pImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




        setContentView(R.layout.activity_edit_place);
        edtplacename = findViewById(R.id.edtplacename);
        edtphoneno = findViewById(R.id.edtphoneno);
        progressDialog = new ProgressDialog(this);
        edtdescription = findViewById(R.id.edtdescription);
        imageView2 = findViewById(R.id.imageView2);
        databaseReference = FirebaseDatabase.getInstance().getReference("Product").child(AdminDashboardAdopter.pKey);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String pContactNo = dataSnapshot.child("fTime").getValue(String.class);
                String pDescription = dataSnapshot.child("fDes").getValue(String.class);
                pImage = dataSnapshot.child("fImg").getValue(String.class);
                String pName = dataSnapshot.child("fName").getValue(String.class);
                edtplacename.setText(pName);
                edtphoneno.setText(pContactNo);
                edtdescription.setText(pDescription);
                Picasso.get()
                        .load(pImage)
                        .placeholder(R.mipmap.ic_launcher)
                        .fit()
                        .centerCrop()
                        .into(imageView2);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void chooseimage(View view) {
        openFileChooser();
    }
    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }
    public void addPlace(View view) {
        if(edtplacename.getText().toString().isEmpty()){
            edtplacename.setError("Please enter place name");
        }else {

            if(edtphoneno.getText().toString().isEmpty()){
                edtphoneno.setError("Please enter contact no.");
            }else {
                if(edtdescription.getText().toString().isEmpty()){
                    edtdescription.setError("Please enter description");
                }else {
                    mStorageRef = FirebaseStorage.getInstance().getReference("Place_Images");
                    mDatabaseRef = FirebaseDatabase.getInstance().getReference("Product");
                    uploadResult();
                }
            }

        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            mImageUri = data.getData();
            Picasso.get().load(mImageUri).into(imageView2);
        }
    }
    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }
    private void uploadResult() {
        if (mImageUri != null) {
            progressDialog.setMessage("Please wait ...");
            progressDialog.show();
            final StorageReference storageReference = mStorageRef.child(System.currentTimeMillis() + "." + getFileExtension(mImageUri));
            mUploadTask = storageReference.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            Toast.makeText(EditPlaceActivity.this, "Updated", Toast.LENGTH_SHORT).show();
                            mDatabaseRef.child(AdminDashboardAdopter.pKey).child("fImg").setValue(uri.toString());
                            mDatabaseRef.child(AdminDashboardAdopter.pKey).child("fName").setValue(edtplacename.getText().toString());
                            mDatabaseRef.child(AdminDashboardAdopter.pKey).child("fTime").setValue(edtphoneno.getText().toString());
                            mDatabaseRef.child(AdminDashboardAdopter.pKey).child("fDes").setValue(edtdescription.getText().toString());
                            progressDialog.dismiss();
                        }
                    });
                }
            });
        } else {
            Toast.makeText(EditPlaceActivity.this, "Updated", Toast.LENGTH_SHORT).show();
            mDatabaseRef.child(AdminDashboardAdopter.pKey).child("fImg").setValue(pImage);
            mDatabaseRef.child(AdminDashboardAdopter.pKey).child("fName").setValue(edtplacename.getText().toString());
            mDatabaseRef.child(AdminDashboardAdopter.pKey).child("fTime").setValue(edtphoneno.getText().toString());
            mDatabaseRef.child(AdminDashboardAdopter.pKey).child("fDes").setValue(edtdescription.getText().toString());

        }
    }
}