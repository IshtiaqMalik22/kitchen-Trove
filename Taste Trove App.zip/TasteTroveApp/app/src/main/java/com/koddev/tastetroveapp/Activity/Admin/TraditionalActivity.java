package com.koddev.tastetroveapp.Activity.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.Adapter.AdminDashboardAdopter;
import com.koddev.tastetroveapp.Model.Food;
import com.koddev.tastetroveapp.R;

import java.util.ArrayList;
import java.util.List;

public class TraditionalActivity extends AppCompatActivity {
    FloatingActionButton add;
    FirebaseAuth firebaseAuthe;
    RecyclerView mRecyclerView;
    List<Food> mUploads;
    AdminDashboardAdopter homeAdopter;
    DatabaseReference mDataBaseReference;
    ProgressBar mProgressCircle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traditional);
        add = findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TraditionalActivity.this,AddTraditionalActivity.class));
            }
        });
        showData();

    }
    public void  showData(){
        mProgressCircle = findViewById(R.id.progress_circle);
        mRecyclerView = findViewById(R.id.mRecyclerView);
        mUploads = new ArrayList<>();
        homeAdopter = new AdminDashboardAdopter(this, mUploads);
        mRecyclerView.setAdapter(homeAdopter);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this,1));
        mDataBaseReference = FirebaseDatabase.getInstance().getReference("Product");
        mDataBaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUploads.clear();
                for(DataSnapshot postSnapShot : dataSnapshot.getChildren())
                {
                    Food product = postSnapShot.getValue(Food.class);
                    if(product.getfCategory().equals("Traditional")) {
                        mUploads.add(product);
                        mProgressCircle.setVisibility(View.INVISIBLE);
                    }

                }
                homeAdopter.notifyDataSetChanged();
                mProgressCircle.setVisibility(View.INVISIBLE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(TraditionalActivity.this, databaseError.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}