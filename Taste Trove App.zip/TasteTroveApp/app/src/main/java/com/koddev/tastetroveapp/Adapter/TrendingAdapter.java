package com.koddev.tastetroveapp.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.Activity.Constants;
import com.koddev.tastetroveapp.Activity.DetailActivity;
import com.koddev.tastetroveapp.Model.Favourite;
import com.koddev.tastetroveapp.Model.Food;
import com.koddev.tastetroveapp.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class TrendingAdapter extends RecyclerView.Adapter<TrendingAdapter.RecyclerHolder> {
    private Context mContext;
    private List<Food> mUploads;

    public TrendingAdapter(Context mContext, List<Food> mUploads) {
        this.mContext = mContext;
        this.mUploads = mUploads;
    }

    @Override
    public RecyclerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.trending_list, parent, false);
        return new RecyclerHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerHolder holder, @SuppressLint("RecyclerView") int position) {
        Food uploadCurrent = mUploads.get(position);
        holder.txtname.setText(uploadCurrent.getfName());
        holder.txttime.setText(uploadCurrent.getfTime());
        holder.txtrate.setText(uploadCurrent.getfRating());
        Picasso.get().load(uploadCurrent.getfImg()).into(holder.imageView);


        // Check if the product is in the user's favorites
        checkFavoriteStatus(uploadCurrent.getfID(), holder);

        // Handle favorite icon click
        holder.imageViewFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleFavoriteStatus(uploadCurrent.getfID(), holder,  position );
            }
        });
    }

    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public class RecyclerHolder extends RecyclerView.ViewHolder {
        ImageView imageView,imageViewFav;
        TextView txtname,txtrate,txttime;
        public RecyclerHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            txtname = itemView.findViewById(R.id.txtname);
            txtrate = itemView.findViewById(R.id.txtrate);
            txttime = itemView.findViewById(R.id.txttime);
            imageViewFav = itemView.findViewById(R.id.imageViewFav);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    Food uploadCurrent = mUploads.get(position);
                    Constants.pID_Detail = uploadCurrent.getfID();
                    Constants.videoURL = uploadCurrent.getfURL();
                    mContext.startActivity(new Intent(mContext, DetailActivity.class));
                }
            });
        }
    }
    private void toggleFavoriteStatus(String productId, RecyclerHolder holder, int position) {
        DatabaseReference favoritesRef;
        FirebaseAuth auth;
        auth = FirebaseAuth.getInstance();
        if(auth.getCurrentUser()!=null){
            favoritesRef = FirebaseDatabase.getInstance().getReference("isFavorites").child(auth.getCurrentUser().getUid());
            favoritesRef.child(productId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists() && snapshot.getValue(Boolean.class)) {
                        // If it's currently a favorite, remove it from favorites (set to false)
                        favoritesRef.child(productId).setValue(false);
                        removeFav(position);
                        holder.imageViewFav.setImageResource(R.drawable.baseline_favorite_border_24);

                    } else {
                        // If it's not a favorite, add it to favorites (set to true)
                        favoritesRef.child(productId).setValue(true);
                        addToFav(position);
                        holder.imageViewFav.setImageResource(R.drawable.baseline_favorite_24_red);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Handle error
                }
            });
        }else {
            Toast.makeText(mContext, "Login now", Toast.LENGTH_SHORT).show();
        }

    }
    /**
     * Check if the product is already favorited and update the icon color accordingly.
     */
    private void checkFavoriteStatus(String productId, RecyclerHolder holder) {
        DatabaseReference favoritesRef;
        FirebaseAuth auth;
        auth = FirebaseAuth.getInstance();
        if(auth.getCurrentUser()!=null){
            favoritesRef = FirebaseDatabase.getInstance().getReference("isFavorites").child(auth.getCurrentUser().getUid());
            favoritesRef.child(productId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists() && snapshot.getValue(Boolean.class)) {
                        // Product is a favorite, show red heart
                        holder.imageViewFav.setImageResource(R.drawable.baseline_favorite_24_red);


                    } else {
                        // Product is not a favorite, show gray heart
                        holder.imageViewFav.setImageResource(R.drawable.baseline_favorite_border_24);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Handle error
                }
            });
        }

    }
    public void addToFav(int position) {
        FirebaseAuth firebaseAuth;
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        if (firebaseUser != null) {
            String uid = firebaseUser.getUid();
            DatabaseReference mdatabase2 = FirebaseDatabase.getInstance().getReference().child("Favourite").child(uid);
            Food uploadCurrent = mUploads.get(position);
            Favourite favourite = new Favourite(
                    uploadCurrent.getfName(),
                    uploadCurrent.getfDes(),
                    uploadCurrent.getfRating(),
                    "null",
                    uploadCurrent.getfImg(),
                    uid,
                    uploadCurrent.getfID()
            );
            mdatabase2.child(uploadCurrent.getfID()).setValue(favourite).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    Toast.makeText(mContext, "Favourite", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
    public void removeFav(int position){
        FirebaseAuth firebaseAuth;
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        if (firebaseUser != null) {
            String uid = firebaseUser.getUid();
            Food uploadCurrent = mUploads.get(position);
            DatabaseReference mdatabase2 = FirebaseDatabase.getInstance().getReference().child("Favourite").child(uid);
            mdatabase2.child(uploadCurrent.getfID()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    Toast.makeText(mContext, "Remove", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
