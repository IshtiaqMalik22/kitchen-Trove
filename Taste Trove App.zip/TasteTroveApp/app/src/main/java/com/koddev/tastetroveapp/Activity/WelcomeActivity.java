package com.koddev.tastetroveapp.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.MainActivity;
import com.koddev.tastetroveapp.Model.User;
import com.koddev.tastetroveapp.R;

public class WelcomeActivity extends AppCompatActivity {
    TextView loginButton,signupButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        getSupportActionBar().hide();
        loginButton = findViewById(R.id.loginButton);
        signupButton = findViewById(R.id.signupButton);

        // Set click listener for the Login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBottomSheetDialogLogin();
            }
        });
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBottomSheetDialogRegister();
            }
        });
    }

    EditText edtemail,edtpassword;
    FirebaseAuth firebaseAuthe;
    ProgressDialog logProgressDialog;
    DatabaseReference mDatabaseRef;
    private void showBottomSheetDialogLogin() {

        // Create a BottomSheetDialog instance
        View view = getLayoutInflater().inflate(R.layout.bottom_sheet_login, null);
        BottomSheetDialog dialog = new BottomSheetDialog(this,R.style.BottomSheetDialog); // Style here
        dialog.setContentView(view);
        dialog.show();
        TextView txtclose = dialog.findViewById(R.id.txtclose);
        LinearLayout lineLogin = dialog.findViewById(R.id.lineLogin);
        edtemail = dialog.findViewById(R.id.edtemail);
        edtpassword = dialog.findViewById(R.id.edtpassword);
        logProgressDialog =new ProgressDialog(this);
        firebaseAuthe= FirebaseAuth.getInstance();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference();
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        lineLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtemail.getText().toString().isEmpty()){
                    edtemail.setError("Please enter email");
                    Toast.makeText(WelcomeActivity.this, "Please enter email", Toast.LENGTH_SHORT).show();
                }else {
                    if(edtpassword.getText().toString().isEmpty()){
                        edtpassword.setError("Please enter password");
                        Toast.makeText(WelcomeActivity.this, "Please enter password", Toast.LENGTH_SHORT).show();
                    }else {
                        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                        if(!edtemail.getText().toString().matches(emailPattern))
                        {
                            Toast.makeText(WelcomeActivity.this, "Please enter valid email", Toast.LENGTH_SHORT).show();
                        }else {
                            if(edtpassword.getText().toString().length() >= 6){
                                userLogin(dialog);
                            }else {
                                Toast.makeText(WelcomeActivity.this, "Password length greater then 5", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                }
            }
        });

    }
    public void userLogin(BottomSheetDialog dialog){
        logProgressDialog.setMessage("Please wait....");
        logProgressDialog.setCanceledOnTouchOutside(false);
        logProgressDialog.show();
        Query query = mDatabaseRef.child("User").orderByChild("uEmail").equalTo(edtemail.getText().toString().trim());
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // dataSnapshot is the "issue" node with all children with id 0
                    for (DataSnapshot user : dataSnapshot.getChildren()) {
                        // do something with the individual "issues"
                        User usersBean = user.getValue(User.class);
                        if (usersBean.getuType().equals("User")) {
                            firebaseAuthe.signInWithEmailAndPassword(edtemail.getText().toString(), edtpassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(WelcomeActivity.this, "User Login", Toast.LENGTH_SHORT).show();
                                        logProgressDialog.dismiss();
                                        dialog.dismiss();
                                        startActivity(new Intent(WelcomeActivity.this, MainActivity.class));
                                        finishAffinity();

                                    }else{
                                        Toast.makeText(WelcomeActivity.this, "Wong Password", Toast.LENGTH_SHORT).show();
                                        logProgressDialog.dismiss();
                                        dialog.dismiss();
                                    }
                                }
                            });
                        }else {
                            Toast.makeText(WelcomeActivity.this, "User not exits", Toast.LENGTH_LONG).show();
                            logProgressDialog.dismiss();
                            dialog.dismiss();
                        }

                    }
                } else {
                    Toast.makeText(WelcomeActivity.this, "User not exits", Toast.LENGTH_LONG).show();
                    logProgressDialog.dismiss();
                    dialog.dismiss();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                logProgressDialog.dismiss();
            }
        });
    }
    EditText edtname2,edtemail2,edtcontact2,edtpassword2;
    DatabaseReference mdatabase2;
    ProgressDialog logProgressDialog2;
    FirebaseAuth firebaseAuth2;
    public void showBottomSheetDialogRegister(){
        // Create a BottomSheetDialog instance
        View view = getLayoutInflater().inflate(R.layout.bottom_sheet_register, null);
        BottomSheetDialog dialog = new BottomSheetDialog(this,R.style.BottomSheetDialog); // Style here
        dialog.setContentView(view);
        dialog.show();
        LinearLayout lineRegister = dialog.findViewById(R.id.lineRegister);
        edtname2 = dialog.findViewById(R.id.edtname);
        edtemail2 = dialog.findViewById(R.id.edtemail);
        edtcontact2 = dialog.findViewById(R.id.edtcontact);
        edtpassword2 = dialog.findViewById(R.id.edtpassword);
        logProgressDialog2 =new ProgressDialog(this);
        firebaseAuth2 = FirebaseAuth.getInstance();
        lineRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtname2.getText().toString().isEmpty()){
                    edtname2.setError("Please enter your name");
                    Toast.makeText(WelcomeActivity.this, "Please enter your name", Toast.LENGTH_SHORT).show();
                }else {
                    if(edtemail2.getText().toString().isEmpty()){
                        edtemail2.setError("Please enter your email");
                        Toast.makeText(WelcomeActivity.this, "Please enter your email", Toast.LENGTH_SHORT).show();
                    }else {
                        if(edtcontact2.getText().toString().isEmpty()){
                            edtcontact2.setError("Please enter your number");
                            Toast.makeText(WelcomeActivity.this, "Please enter your number", Toast.LENGTH_SHORT).show();
                        }else {
                            if(edtpassword2.getText().toString().isEmpty()){
                                edtpassword2.setError("Please enter your password");
                                Toast.makeText(WelcomeActivity.this, "Please enter your password", Toast.LENGTH_SHORT).show();
                            }else {
                                if (edtcontact2.getText().toString().length() >=11){
                                    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                                    if(!edtemail2.getText().toString().matches(emailPattern))
                                    {
                                        Toast.makeText(WelcomeActivity.this, "Please enter valid email", Toast.LENGTH_SHORT).show();
                                        edtemail2.setError("Please enter valid email");
                                    }else {
                                        mdatabase2 = FirebaseDatabase.getInstance().getReference().child("User");
                                        register(logProgressDialog2,dialog);
                                    }
                                }else {
                                    Toast.makeText(WelcomeActivity.this, "Invalid Phone Number", Toast.LENGTH_SHORT).show();
                                    edtcontact2.setError("Invalid Phone Number");
                                }

                            }
                        }
                    }
                }
            }
        });
    }
    public void register(ProgressDialog logProgressDialog, BottomSheetDialog dialog){
        logProgressDialog.setTitle("User Register");
        logProgressDialog.setMessage("Please wait....");
        logProgressDialog.setCanceledOnTouchOutside(false);
        logProgressDialog.show();
        firebaseAuth2.createUserWithEmailAndPassword(edtemail2.getText().toString(),edtpassword2.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    FirebaseUser firebaseUser = firebaseAuth2.getCurrentUser();
                    String autoID = firebaseUser.getUid();
                    User user = new User(
                            edtname2.getText().toString(),
                            edtemail2.getText().toString(),
                            "null",
                            edtcontact2.getText().toString(),
                            edtpassword2.getText().toString(),
                            autoID,
                            "null",
                            "User"
                    );
                    mdatabase2.child(autoID).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(WelcomeActivity.this, "User Register Successfully", Toast.LENGTH_SHORT).show();
                            logProgressDialog.dismiss();
                            dialog.dismiss();
                        }
                    });
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(WelcomeActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}