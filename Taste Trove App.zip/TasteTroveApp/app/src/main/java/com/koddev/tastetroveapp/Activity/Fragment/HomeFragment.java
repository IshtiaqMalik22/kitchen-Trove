package com.koddev.tastetroveapp.Activity.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.koddev.tastetroveapp.Activity.CategoryActivity;
import com.koddev.tastetroveapp.Activity.Constants;
import com.koddev.tastetroveapp.Activity.SearchActivity;
import com.koddev.tastetroveapp.Activity.SeeAllActivity;
import com.koddev.tastetroveapp.Adapter.TrendingAdapter;
import com.koddev.tastetroveapp.Model.Food;
import com.koddev.tastetroveapp.R;

import java.util.ArrayList;
import java.util.List;


public class HomeFragment extends Fragment {

    View root;
    LinearLayout linearFood,l1,l2,l3,l4;
    TextView txtsearch;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_home, container, false);
        linearFood = root.findViewById(R.id.linearFood);
        l1 = root.findViewById(R.id.l1);
        l2 = root.findViewById(R.id.l2);
        l3 = root.findViewById(R.id.l3);
        l4 = root.findViewById(R.id.l4);
        linearFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), SeeAllActivity.class));
            }
        });
        txtsearch = root.findViewById(R.id.txtsearch);
        txtsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), SearchActivity.class));
            }
        });
        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.type = "All";
                startActivity(new Intent(getContext(), CategoryActivity.class));
            }
        });
        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.type = "Traditional";
                startActivity(new Intent(getContext(), CategoryActivity.class));
            }
        });
        l3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.type = "Desert";
                startActivity(new Intent(getContext(), CategoryActivity.class));
            }
        });
        l4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.type = "Drink";
                startActivity(new Intent(getContext(), CategoryActivity.class));
            }
        });
        trending();
        return  root;
    }
    RecyclerView rcTrend;
    List<Food> mUploads;
    TrendingAdapter trendingAdapter;
    DatabaseReference mDataBaseReference;
    ProgressBar progress_circle_trend;
    public void  trending(){
        rcTrend = root.findViewById(R.id.rcTrend);
        progress_circle_trend = root.findViewById(R.id.progress_circle_trend);
        mUploads = new ArrayList<>();
        trendingAdapter = new TrendingAdapter(getContext(), mUploads);
        rcTrend.setAdapter(trendingAdapter);
        rcTrend.setLayoutManager(new GridLayoutManager(getContext(),2));
        mDataBaseReference = FirebaseDatabase.getInstance().getReference("Product");
        mDataBaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // dataSnapshot is the "issue" node with all children with id 0
                mUploads.clear();
                for (DataSnapshot user : dataSnapshot.getChildren()) {
                    // do something with the individual "issues"
                    Food product = user.getValue(Food.class);
                    if (mUploads.size() < 6) {
                        mUploads.add(product);
                        progress_circle_trend.setVisibility(View.GONE);
                    }

                }
                trendingAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }




}