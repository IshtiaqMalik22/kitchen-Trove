package com.koddev.tastetroveapp.Activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.koddev.tastetroveapp.Model.User;
import com.koddev.tastetroveapp.R;

public class RegisterActivity extends AppCompatActivity {
    EditText edtname,edtemail,edtcontact,edtpassword;
    CheckBox checkbox;
    DatabaseReference mdatabase;
    ProgressDialog logProgressDialog;
    FirebaseAuth firebaseAuth;
    Spinner spinnerlevel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();
        checkbox = findViewById(R.id.checkbox);
        edtname = findViewById(R.id.edtname);
        spinnerlevel = findViewById(R.id.spinnerlevel);
        edtemail = findViewById(R.id.edtemail);
        edtcontact = findViewById(R.id.edtcontact);
        edtpassword = findViewById(R.id.edtpassword);
        logProgressDialog =new ProgressDialog(this);
        firebaseAuth = FirebaseAuth.getInstance();

        checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Show the password
                edtpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            } else {
                // Hide the password
                edtpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        });

    }

    public void closed(View view) {
        finish();
    }

    public void signUp(View view) {
        if(edtname.getText().toString().isEmpty()){
            edtname.setError("Please enter your name");
            Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show();
        }else {
            if(edtemail.getText().toString().isEmpty()){
                edtemail.setError("Please enter your email");
                Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show();
            }else {
                if(edtcontact.getText().toString().isEmpty()){
                    edtcontact.setError("Please enter your number");
                    Toast.makeText(this, "Please enter your number", Toast.LENGTH_SHORT).show();
                }else {
                    if(edtpassword.getText().toString().isEmpty()){
                        edtpassword.setError("Please enter your password");
                        Toast.makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show();
                    }else {
                        if (edtcontact.getText().toString().length() >=11){
                            String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                            if(!edtemail.getText().toString().matches(emailPattern))
                            {
                                Toast.makeText(this, "Please enter valid email", Toast.LENGTH_SHORT).show();
                                edtemail.setError("Please enter valid email");
                            }else {
                                mdatabase = FirebaseDatabase.getInstance().getReference().child("User");
                                register();
                            }
                        }else {
                            Toast.makeText(this, "Invalid Phone Number", Toast.LENGTH_SHORT).show();
                            edtcontact.setError("Invalid Phone Number");
                        }

                    }
                }
            }
        }
    }
    public void register(){
        logProgressDialog.setTitle("User Register");
        logProgressDialog.setMessage("Please wait....");
        logProgressDialog.setCanceledOnTouchOutside(false);
        logProgressDialog.show();
        firebaseAuth.createUserWithEmailAndPassword(edtemail.getText().toString(),edtpassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
                    String autoID = firebaseUser.getUid();
                    User user = new User(
                            edtname.getText().toString(),
                            edtemail.getText().toString(),
                            spinnerlevel.getSelectedItem().toString(),
                            edtcontact.getText().toString(),
                            edtpassword.getText().toString(),
                            autoID,
                            "null",
                            "User"
                    );
                    mdatabase.child(autoID).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(RegisterActivity.this, "User Register Successfully", Toast.LENGTH_SHORT).show();
                            logProgressDialog.dismiss();
                            finish();
                        }
                    });
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                logProgressDialog.dismiss();
                Toast.makeText(RegisterActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}